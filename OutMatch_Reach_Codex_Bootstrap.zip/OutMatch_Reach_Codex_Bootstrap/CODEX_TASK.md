# Codex task: build the OutMatch Reach Evolution Lab

You have zero external project context. Everything authoritative that is available is in this repository/package. Do not infer rules from the names of files or from an older OutMatch implementation.

## Product to build

Build a static web application suitable for GitHub Pages. It must run the OutMatch Reach seven-population evolutionary ecology entirely client-side.

The first canonical generation is ReachR29. The user must be able to continue indefinitely to R30, R31, and later generations without Codex or ChatGPT being involved.

### Required user capabilities

**Run evolution**
- Run one next generation.
- Run N generations sequentially.
- Show stage/game progress.
- Pause safely and resume an interrupted generation.
- Never overwrite a completed earlier generation.

**Reports**
- directional 7×7 natural-elimination matrix;
- genetic similarity within and between the seven populations;
- P/A/C training rates and shares;
- P/A/C kill rates and shares, victim-type rates, and pike-poke rates;
- individual general vs general and general vs population matchup reports;
- deterministic play-by-play board viewer for selected games.

**Levers**
- mutation rate / inheritance probabilities;
- wildcard slot count and probability;
- selective-pressure parameters described in `spec/ECOLOGY.md`;
- manual copy/move/reassignment of generals into populations, with explicit audit records and population-size validation.

**Data portability**
- auto-save completed generations locally in IndexedDB;
- download a single generation as a self-contained `.omgen` ZIP;
- upload/import a generation `.omgen` and continue from it;
- do not implement cloud sync in this version.

## Architectural constraints

1. Static hosting only. No required backend.
2. Put simulation in Web Workers. The UI must remain responsive during tens of thousands of games.
3. Use a pure deterministic headless game engine. Do not run DOM-based gameplay for tournament battles.
4. Games are deterministic given the two genomes, colors and rules version. Stochasticity is needed for breeding/mutation/wildcards; use the documented stable PRNG and record its seed.
5. Store compact game ledgers, not full traces for every game. Generate full action traces only on replay/on demand.
6. Checkpoint partial tournament progress frequently enough that mobile/browser suspension does not throw away an entire generation.
7. Completed generations are immutable. A rule/control change creates a new descendant generation or a new local run/branch; it does not rewrite history.

## Implementation order — do not skip the validation gates

### Phase 1 — exact headless engine
- Port the evaluator from `reference/g67v2/current/CURRENT_PLAYABLE_ENGINE_EXACT.js`.
- Apply only the Reach pike-poke combat patch.
- Add instrumentation needed by the ledger.
- Pass `fixtures/r29_golden_games.csv` before optimizing.

### Phase 2 — R29 analytics and exact fitness
- Load the shipped R29 checkpoint/ledger/rankings.
- Reproduce the fixture elimination matrix, genetic similarity, unit-rate reports and all 343 R29 fitness values.
- The reference fitness script in `scripts/verify_r29_fitness.py` is an executable oracle.

### Phase 3 — tournament runner
- Implement the three-stage Reach schedule and verify its schedule invariants.
- The runner must support a fresh candidate population and create the same ledger schema plus the additional future fields specified in the data dictionary.

### Phase 4 — migration/breeding
- Implement current R29 migration/breeding rules using fixed mutation ranges from `seed/mutation_ranges.json`.
- Use a stable documented PRNG; future generation seeds default to parent seed + 1.
- R29's seed is historical. R30 begins the new browser-canonical stochastic branch; there is no hidden historical R30 result to reproduce.

### Phase 5 — IndexedDB and import/export
- Implement local run/generation stores and crash-resume progress.
- Implement `.omgen` download/upload with validation/checksums.

### Phase 6 — UI/reports/replay
- Build the user-facing lab described in `spec/UI.md`.
- Add deterministic replay action logging/viewer.

### Phase 7 — GitHub Pages deployment
- Add normal build/test scripts and a GitHub Pages workflow or a Pages-compatible static `dist/` build.
- Document local development and deployment in the repository README.

## Definition of done

Do not call the project done because a dashboard renders. The project is complete when the acceptance tests in `spec/ACCEPTANCE_TESTS.md` pass, including exact R29 fitness reproduction, report fixture reproduction, legal pike-poke tests, generation persistence, and `.omgen` round-trip continuation.
