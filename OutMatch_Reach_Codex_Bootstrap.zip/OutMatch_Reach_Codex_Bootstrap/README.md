# OutMatch Reach Ecology — zero-context Codex bootstrap

This package is intended to be copied into a **brand-new repository** and handed to Codex with no prior chat context.

The goal is to build a static GitHub Pages browser application that runs the current OutMatch seven-population evolutionary ecology locally in the user's browser, starting from the complete **ReachR29** population. The application is not a cloud service. GitHub Pages hosts the code; evolving generations and battle ledgers live in browser IndexedDB unless the user explicitly downloads them.

## Start here

Codex should read, in order:

1. `CODEX_TASK.md` — implementation mandate and completion criteria.
2. `SOURCE_OF_TRUTH.md` — precedence rules; crucial because historical files contain superseded rules.
3. `spec/GAME_ENGINE.md` — exact game engine source and Reach pike-poke patch.
4. `spec/ECOLOGY.md` — tournament, fitness, migration and breeding.
5. `spec/STORAGE_AND_FILES.md` — IndexedDB and `.omgen` generation files.
6. `spec/REPORTS.md` — required reports and formulas.
7. `spec/UI.md` — required user controls and screens.
8. `spec/ACCEPTANCE_TESTS.md` — gates Codex must pass before considering the project complete.

## Canonical current state

`seed/r29/Reach_R29_Complete_Checkpoint.json` is the current population/state handoff. It contains 343 generals, 49 in each of seven populations. R29 is complete and has a full tournament ledger and rankings.

The exact current G67 genome-to-behavior JavaScript is preserved under `reference/g67v2/current/`. It is the gameplay/evaluator source to port. It is **pre-Reach**, so the only deliberate combat rules patch is the stationary pike poke described in `spec/GAME_ENGINE.md`.

## Critical warning

Do not implement the ecology from older G0 succession-policy text or the old G67 tournament format. Those files are historical provenance only. Current ReachR29 rules in this package take precedence.

## What the finished product should feel like

A self-contained evolutionary laboratory in a browser:

- open the GitHub Pages app;
- R29 is available on first use;
- inspect reports;
- adjust ecological levers;
- queue manual population interventions;
- run R30, R31, ... locally in Web Workers;
- close/reopen the browser and continue from IndexedDB;
- download any completed generation as a portable `.omgen` file;
- upload an `.omgen` file in another browser and continue from it;
- select a historical battle and regenerate its play-by-play deterministically.

No server and no cloud sync are required.
