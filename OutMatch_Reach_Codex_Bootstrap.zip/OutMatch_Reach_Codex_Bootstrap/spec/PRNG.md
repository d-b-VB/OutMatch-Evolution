# Breeding PRNG

Games should remain deterministic and should not consume breeding randomness.

For browser-canonical R30 onward, use `splitmix64-v1` as shown in `examples/splitmix64_reference.js` unless there is a compelling implementation reason to choose an equally explicit versioned integer PRNG before the first new generation is committed.

Rules:
- seed stored as decimal string;
- default child-generation seed = parent numeric seed + 1;
- parent R29 seed is `202608231655`, so default R30 seed is `202608231656`;
- deterministic loop/schedule ordering is part of the breeding contract;
- never allow Web Worker completion order to determine RNG draw order;
- if RNG algorithm ever changes later, bump PRNG version in generation manifest; do not silently change an existing version.
