# Acceptance tests

These are completion gates, not suggestions.

## A. Seed integrity

- Load `seed/r29/Reach_R29_Complete_Checkpoint.json`.
- Assert 343 unique IDs.
- Assert seven populations exactly and 49 members each.
- Assert each genome has exactly 112 numeric loci.
- Assert `nextRecruitingPopulation == horse_hunters`.
- Verify supplied seed file SHA-256 values against `SOURCE_CHECKSUMS.json`.

## B. Reach combat rules

Unit tests:
1. Adjacent enemy + unactivated P → legal stationary `poke` exists.
2. Applying poke removes victim, P position unchanged, P activation consumed.
3. P can still ordinary-move and advance-capture.
4. P cannot poke non-adjacent enemy.
5. P cannot poke twice in one side turn.
6. Poke kill is credited to P attacker type and correct victim type.
7. Poke action appears in trace and increments poke + poke-kill instrumentation.
8. Existing A/C movement/combat and reinforcement tests remain unchanged.

## C. G67 evaluator preservation

Before applying Reach patch, or with poke unavailable in states without adjacent enemy P:
- recruitment choice must match the extracted exact G67 evaluator for representative R29 genomes;
- deployment choice must match;
- ordered candidate actions / selected action should match for representative non-poke states.

Do not replace the 112-locus evaluator with an older simplified doctrine model.

## D. Golden Reach games

Replay every row in `fixtures/r29_golden_games.csv` using its Red/Blue IDs from the R29 checkpoint.

Require exact equality for:
- outcome;
- winner;
- ending round;
- P/A/C trained by each side;
- pike pokes by each side;
- kills by P/A/C attacker type;
- victim P/A/C counts.

The fixture intentionally includes high-poke games, early eliminations, draws and multiple tournament stages/population pairs.

If this fails, do not workerize/optimize the engine yet.

## E. Raw R29 ledger invariants

- exactly 72,556 games;
- Stage 1 exactly 43,218;
- Stage 2 exactly 28,224;
- Challenger exactly 1,114;
- R29 challenger round count = 1;
- all final top14 specialists are fully evaluated;
- complete specialist has 588 games;
- Generalists have complete six-population exposure.

## F. Exact R29 fitness

Port the formula from `spec/ECOLOGY.md` / `scripts/verify_r29_fitness.py`.

Compare all 343 rows to `seed/r29/Reach_R29_Full_Staged_Rankings.csv`.

Target: max absolute error < `1e-12` for both `base` and final `fitness` with ordinary JS double precision.

The supplied Python oracle already achieves this. See `fixtures/r29_fitness_formula_verification.json`.

## G. Report regression

From the R29 checkpoint/ledger, reproduce:
- `fixtures/r29_elimination_matrix_expected.json`;
- `fixtures/r29_genetic_similarity_expected.json` within 1e-12 mean tolerance;
- `fixtures/r29_population_unit_rates_expected.json` within floating tolerance.

## H. Tournament scheduler tests

For a synthetic 49×7 roster:
- Stage 1 schedule contains 43,218 unique color-specific games and only the required population pairings;
- Stage 2 adds 28,224 unique color-specific games with no duplicates;
- each tentative specialist elite has 588 games after Stage 2;
- non-tentative specialists have 308 after Stage 2;
- challenger completion fills only missing games;
- iterative challenger cleanup terminates only when final top14 are fully evaluated.

On the R29 known elite/challenger state, scheduler accounting must reproduce the R29 stage counts.

## I. Breeding invariants

With fixed controls and seed:
- repeat run produces byte-equivalent child genomes/roster ordering;
- worker count does not affect offspring;
- each population ends with exactly 49;
- 14 survivor/entrant slots before births;
- guaranteed fatherhood events follow ranks 1–7 plus extra ranks 1–3, excluding outgoing/ineligible parents;
- ordinary/self inheritance frequencies are implemented per configuration;
- mutation values always fall inside fixed `seed/mutation_ranges.json` bounds;
- wildcard genomes have 112 valid loci inside bounds;
- incoming migrants/manual entrants do not breed in insertion cycle.

## J. Persistence/resume

- Start a generation, stop after a persisted partial batch, reload page, resume.
- Resumed final ledger/rankings/checkpoint must exactly match an uninterrupted run using same controls/seed.
- Completed parent generation remains unchanged.

## K. `.omgen` round trip

1. Complete a test generation.
2. Download `.omgen`.
3. Clear/use a separate IndexedDB test database.
4. Import `.omgen`.
5. Validate checksums/schema/population/loci.
6. Imported reports match original.
7. Run the next generation from imported state with same controls/seed and confirm identical result to original continuation.

## L. Manual interventions

- manual move, copy and custom entrant are recorded in child manifest;
- source/destination semantics match `ECOLOGY.md`;
- no silent population-size drift;
- invalid duplicate IDs / malformed genomes are rejected;
- subsequent generation can be exported/imported with interventions preserved.

## M. UI smoke tests

On desktop and narrow mobile viewport:
- active generation visible;
- next-generation run starts and progress updates without freezing main UI;
- reports navigable;
- general can be selected for matchup/replay/intervention;
- generation download and upload reachable;
- controls clearly show when values differ from R29 defaults.
