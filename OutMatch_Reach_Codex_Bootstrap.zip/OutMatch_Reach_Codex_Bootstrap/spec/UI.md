# Browser UI requirements

The app should be usable on both laptop and phone. A large table can scroll horizontally, but core controls must remain touch-friendly.

## Navigation

Suggested top-level screens/tabs:

1. **Dashboard**
2. **Run**
3. **Populations**
4. **Reports**
5. **Matchups**
6. **Replay**
7. **Controls**
8. **Data**

## Dashboard

Show:
- active run and generation;
- seven population cards;
- top-ranked general per population;
- latest generation-v-generation deltas;
- compact elimination matrix;
- simulation/import status.

## Run

Controls:
- Run next generation;
- Run N generations;
- pause after current game batch;
- stop safely at generation boundary;
- resume interrupted generation.

Progress:
- breeding/migration phase;
- tournament stage 1 / stage 2 / challenger round;
- completed/total games for current known stage;
- elapsed time and throughput are fine, but never sacrifice determinism to progress UI.

For multi-generation runs, save each completed generation before starting the next.

## Populations

Seven groups of 49. Sort/filter by:
- rank;
- name/ID;
- origin/generation;
- fitness;
- training/kills/pokes;
- lineage/parents.

General detail drawer/page:
- full genome optionally expandable;
- ancestry metadata;
- fitness components;
- individual unit behavior;
- matchup launcher;
- queue manual intervention.

## Reports

Provide report selector and generation selector.

At minimum:
- 7×7 elimination matrix;
- 7×7 genetic similarity matrix and detailed within/between stats;
- unit training report;
- unit kill report;
- rankings;
- breeding/migration summary;
- generation comparison.

Tables should have CSV/JSON download where practical, separate from the full `.omgen` download.

## Matchups

Select General A and General B or General A vs population.
- historical stats if available;
- launch deterministic exhibition games if not;
- choose colors / both colors;
- launch replay after game.

Never mix exhibition results into the evolutionary selection ledger.

## Replay

Board viewer specified in `REPORTS.md`. Must clearly indicate historical ledger replay vs exhibition.

## Controls

### Breeding
- mutation rate/simple slider;
- advanced inheritance probabilities;
- wildcard slots;
- wildcard probability;
- reset to R29 defaults.

### Selection
Expose the current formula components from `ECOLOGY.md` with labels explaining what each affects. Show a live **Re-score current generation** preview and changed ranks before the user runs the next generation.

### Migration
- enable/disable automatic migration;
- maximum migrants;
- current/next recruiting population readout.

### Manual interventions
Queue list with remove/undo before run:
- move/manual migrant;
- copy into destination;
- advanced imported/replacement genome.

Show exact effect on the child survivor/entrant slots. Block Run if an intervention is invalid.

## Data

- list locally saved generations;
- select active generation / fork into a new run;
- Download Generation (`.omgen`);
- Import Generation;
- delete local run/generation only with confirmation;
- storage usage estimate if browser provides it.

Do not add cloud controls in v1.
