# Implementation notes and non-goals

## Recommended stack

The project can be plain TypeScript/JavaScript + Vite (or another static bundler) with no server. Choose a modest dependency set.

Useful components:
- Web Workers for simulation;
- IndexedDB wrapper (small library such as `idb` is acceptable) or direct IndexedDB;
- ZIP library such as JSZip/fflate for `.omgen`;
- Web Crypto for SHA-256;
- lightweight charting is optional; matrices/tables must work without charts.

## Performance

Correctness first. The supplied R29 ledger proves the intended scale: roughly 72k games/generation under current population size.

After golden-game correctness:
- represent board state compactly;
- minimize allocations in lookahead;
- distribute stable game batches across workers;
- cap worker count sensibly on phones;
- keep breeding RNG on orchestrator thread or use deterministic precomputed draws so worker order cannot affect it.

Do not use the browser DOM engine 72k times.

## Full traces

Do not save full traces for every game. Regenerate them on demand in a trace-enabled single-game mode. The persistent compact ledger is enough for reports and deterministic replay lookup.

## Historical G67 files

The G67 package also discusses its own old 7×7×7 pod tournament/rampage and round-cap adjudication. Those are not the Reach ecology tournament/selection rules. Reuse only the exact game/genome evaluator as specified.

## No cloud

Do not add Supabase/Firebase/authentication/cloud sync. Generation download/upload is the cross-device mechanism for v1.
