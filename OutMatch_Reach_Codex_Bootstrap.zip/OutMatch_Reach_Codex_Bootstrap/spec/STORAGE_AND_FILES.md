# Browser persistence and portable generation files

## Principle

GitHub Pages hosts code. It does not store the evolving experiment.

The browser's IndexedDB is the working persistent database. A generation download is the manual cross-browser/device transfer mechanism for this version. No cloud sync.

## IndexedDB

Suggested database: `outmatch-reach`, schema version 1.

Suggested stores:

### `runs`
Run/branch metadata:
- runId;
- title/optional note;
- created time;
- active generation;
- originating imported generation if any.

### `generations`
One immutable record per completed generation:
- manifest;
- complete checkpoint/343 roster;
- final rankings;
- applied control snapshot;
- applied manual interventions;
- migration/breeding summary;
- cached small report summaries.

### `ledgers`
Large compact ledger for each completed generation, keyed by runId+generation. Storing it separately avoids constantly rewriting huge generation objects.

### `replays`
Optional cached trace-enabled selected games.

### `settings`
UI preferences and currently selected run/generation.

### `run_progress`
Incomplete next-generation transaction:
- parent generation;
- child candidate roster;
- controls/interventions snapshot;
- stage/cursor;
- completed game batches/partial ledger;
- deterministic breeding seed/PRNG version;
- any tentative elite/challenger state needed to resume exactly.

## Crash/suspension resilience

Mobile browsers may suspend the page. Persist progress at bounded intervals, e.g. every 250–500 games or about every five seconds, whichever comes first.

Worker completion order must not influence deterministic output. Assign stable game IDs/schedule order and sort before scoring/saving.

When a generation completes:
1. finish and validate ledger;
2. calculate rankings/reports;
3. write immutable generation + ledger;
4. update active-generation pointer only after successful writes;
5. remove `run_progress`.

An interrupted generation must resume rather than restart if its parent/control/intervention hashes match.

## First load

If no local run exists, offer/create a run seeded from shipped ReachR29 files. Do not re-run R29 automatically: its complete checkpoint/ledger/rankings are supplied.

## Portable generation file: `.omgen`

A `.omgen` file is a ZIP with a custom extension. It must be sufficient to import a completed generation into a different browser and continue evolution from it without older generations.

Recommended structure:

```text
OutMatch_Reach_R030.omgen
  manifest.json
  checkpoint.json
  ledger.csv
  rankings.csv
  controls.json
  interventions.json
  reports/
    elimination-matrix.json
    genetic-similarity.json
    unit-rates.json
    breeding-migration.json
```

### `manifest.json` minimum

```json
{
  "schema": "outmatch-omgen-v1",
  "generation": "ReachR30",
  "parentGeneration": "ReachR29",
  "createdAt": "...",
  "rulesVersion": "reach-browser-v1",
  "engineVersion": "...",
  "breedingPrng": "splitmix64-v1",
  "seed": "202608231656",
  "populationSize": 343,
  "populationSizeEach": 49,
  "locusCount": 112,
  "gameCount": 0,
  "checksums": {
    "checkpoint.json": "sha256:...",
    "ledger.csv": "sha256:...",
    "rankings.csv": "sha256:...",
    "controls.json": "sha256:..."
  }
}
```

Use Web Crypto SHA-256.

## Import validation

Before accepting an `.omgen`:
- recognized schema/version;
- checksums pass;
- checkpoint has exactly seven known populations;
- exactly 49 per population / 343 total;
- every general has unique ID;
- every general has exactly the expected 112 numeric loci;
- no NaN/Infinity;
- ledger references known IDs;
- rules/engine versions are present;
- rankings are internally consistent or can be regenerated from ledger;
- generation seed and PRNG version present.

Do not silently overwrite a local generation with the same ID. Offer:
- import as a new local run/branch; or
- explicit replacement only after confirmation.

## Generation download/upload UI

Every completed generation should show:
- **Download generation**;
- **Import generation** on Data screen;
- file size and generation metadata;
- validation result after import.

Optional later: full-run `.omrun` export. It is not required for v1 and should not delay `.omgen` implementation.
