# Reach seven-population ecology

## Current population

ReachR29 contains 343 generals: 49 per group.

1. `horse_lords`
2. `pike_lords`
3. `archer_lords`
4. `horse_hunters`
5. `pike_hunters`
6. `archer_hunters`
7. `generalists`

There are no within-population ecology battles.

## Tournament schedule

Both colors are always played for every scheduled pair.

### Stage 1 — core

Every specialist plays:
- all 49 Generalists;
- all 49 members of its designated rival population.

Rival pairs:
- Horse Lords ↔ Horse Hunters;
- Pike Lords ↔ Pike Hunters;
- Archer Lords ↔ Archer Hunters.

Generalists therefore play every specialist.

With 49 per group and both colors:
- specialist-v-Generalist games = `6 × 49 × 49 × 2 = 28,812`;
- rival games = `3 × 49 × 49 × 2 = 14,406`;
- Stage 1 total = **43,218**.

Rank each population under the current fitness formula after Stage 1. The specialist top 14 are tentative elites. Generalists are already fully exposed to all six other populations.

### Stage 2 — elite exposure

For every pair of **unrelated specialist populations**, complete games so each tentative top-14 member of either population has played the entire 49-member roster of the other population, both colors. Do not duplicate a game when both contestants are tentative elites.

There are 12 unrelated specialist-population pairs. Per pair:
- pairings = `14×49 + 14×35 = 1,176`;
- games both colors = `2,352`.

Stage 2 total = **28,224**.

A tentative elite specialist now has complete exposure: `6 × 49 × 2 = 588` games. A non-tentative specialist has Stage-1 core games plus games against the 14 elites of each four unrelated specialist populations: `196 + 4×14×2 = 308` games.

### Stage 3 — challenger cleanup

After Stage 2, rerank every population using its currently available population-normalized statistics.

Any specialist currently in the top 14 that is not fully evaluated is a challenger. Complete all of that challenger's missing games against the lower 35 members of each unrelated specialist population, both colors. Avoid duplicate games when multiple challengers require the same matchup.

Rerank, and repeat challenger cleanup until **all final top-14 specialists are fully evaluated**.

R29 needed one challenger round. Four challengers required completion and duplicate avoidance produced **1,114** challenger games. Thus R29 total was:

`43,218 + 28,224 + 1,114 = 72,556`.

Acceptance tests should verify these R29 schedule invariants from the supplied ledger.

## Population-normalized scoring

The staged schedule intentionally gives different generals different numbers of games. Do not compute fitness as a simple raw mean over all games.

For a general:
1. compute its adjusted per-game selection score as described below;
2. group those games by the opponent's population;
3. take the mean adjusted score within each opponent population;
4. combine those population means equally, except Hunters give their designated target population a 6× weight.

This is the current `base` fitness and exactly reproduces every R29 `base` value.

### Raw natural-elimination speed score

At elimination round `r`:
- winner = `1 + 0.5*(20-r)/19`
- loser = `-0.5*(20-r)/19`
- draw = `0`

The `0.5` speed coefficient is a user-adjustable selective-pressure lever. Store the value actually used with every generation.

## Target definitions

| Population | Target population | Target unit for extra credit |
|---|---|---|
| Pike Lords | none weighted 6× | Cavalry / horse (`C`) |
| Horse Hunters | Horse Lords | Cavalry / horse (`C`) |
| Pike Hunters | Pike Lords | Pike (`P`) |
| Archer Hunters | Archer Lords | Archer (`A`) |

## Game-level extra selection credit

Define for a Hunter game:

`coverage = sqrt(targetUnitsKilled / (1 + enemyTargetUnitsTrained))`

The `+1` is the enemy's initial target unit, so the denominator represents target units available, not merely reinforcements.

### Pike Lords and Hunters — target-training elimination bonus

On a **natural-elimination win**:

`adjustedWinnerScore = rawWinnerScore * (1 + sqrt(enemyTargetUnitsTrained))`

Pike Lords use enemy Cavalry trained. Each Hunter uses its target unit.

This applies regardless of the opponent's population; the separate Hunter target-population weight is applied later when population means are combined.

### Hunters — partial credit without winning

Natural-elimination loss:

`adjustedLoserScore = rawLoserScore * (1 - 0.5*coverage)`

Thus target kills can mitigate at most 50% of the negative loss score.

Draw:

`adjustedDrawScore = 0.25*coverage`

The maximum loss mitigation and maximum draw reward are user-adjustable selection levers.

## Hunter base fitness

First compute the adjusted mean against each population. Then:

`base = (6*targetPopulationMean + sum(each of the other five population means)) / 11`

Generalists and Lords use the ordinary equal mean of all opponent-population means they have seen.

## Lord specialization multipliers

Training/recruit fractions and unit kill shares are themselves **opponent-population normalized**:

For each opponent population separately:
- total P/A/C trained by the general in those games → convert to fractions;
- total kills by P/A/C attackers → convert to kill shares;
- for Pike Lords, mean P trained/game.

Then equally average each statistic across opponent populations.

Current final fitness:

- Horse Lord: `base × cavalryRecruitFraction × sqrt(cavalryKillShare)`
- Archer Lord: `base × archerRecruitFraction × sqrt(archerKillShare)`
- Pike Lord: `base × sqrt(meanPikesTrainedPerGame) × sqrt(pikeKillShare)`
- Hunters: `base`
- Generalists: `base`

The reference implementation in `scripts/verify_r29_fitness.py` reproduces every R29 value to <1e-12 error.

## Selection levers to expose

At minimum expose:
- speed-score coefficient (default `0.5`);
- Hunter target-population weight (default `6`);
- target-training win bonus coefficient/exponent (default `1`, `0.5`);
- Hunter loss mitigation maximum (default `0.5`);
- Hunter coverage exponent (default `0.5`);
- Hunter draw reward maximum (default `0.25`);
- Horse/Archer Lord recruit-fraction exponent (default `1`);
- Pike Lord pikes/game exponent (default `0.5`);
- specialized kill-share exponent (default `0.5`).

Changing selection levers can re-score an already completed generation's existing ledger without replaying its games. The UI should show a preview of changed rankings before the next generation is bred.

## Automatic migration

One recruiting population per generation, rotating:

`Horse Lords → Pike Lords → Archer Lords → Horse Hunters → Pike Hunters → Archer Hunters → Generalists → ...`

The R29 construction used Archer Lords. The **next recruiting population for R30 is Horse Hunters**.

Current maximum migrants = **4**.

Scan outsiders. An outsider is eligible when:
- its hypothetical within-destination rank under the destination population's fitness is `<= 24`; and
- that hypothetical rank is strictly better than its current within-population rank.

Priority: lowest hypothetical new rank, then largest rank improvement. Select up to the configured maximum.

Migrants occupy survivor slots in the destination population, displacing lower native survivors as needed. An outgoing top-14 migrant leaves its old population's survivor pool. Incoming migrants do **not** breed in the same R29→R30 breeding cycle; they become ordinary residents after competing in their destination in the next generation.

Migration is an advanced lever: allow enable/disable and max migrants, but default to current R29 behavior.

## Breeding next generation

Use the current-generation final rankings after applying the active selection controls.

Per population:
- next roster size is always 49;
- survivor/entrant pool has 14 slots, adjusted for migration/manual entrants;
- native survivor priority is current within-population rank;
- ranks 1–7 each get one guaranteed-father child;
- ranks 1–3 get one additional guaranteed-father child: 10 guaranteed fatherhood events total before outgoing restrictions;
- parent lottery weight = `1/sqrt(rank)`;
- ordinary mother for a guaranteed father is drawn by the same weighted resident lottery;
- ordinary crosses draw both parents independently by the weighted lottery;
- self-cross is allowed;
- outgoing migrants do not breed in their old population;
- incoming/manual entrants sit out that same breeding cycle.

Fill remaining roster slots with births after survivors/entrants.

### Ordinary cross inheritance per locus

Default:
- 40% father exact;
- 40% mother exact;
- 10% arithmetic mean;
- 5% uniform continuous between the parent values;
- 5% de-novo mutation: uniform continuous within the fixed expanded locus range in `seed/mutation_ranges.json`.

Self-cross:
- 95% parent exact;
- 5% de-novo mutation.

The user must be able to adjust mutation/inheritance probabilities. If UI offers a simple single mutation slider, preserve the relative proportions of the four non-mutation ordinary outcomes when rescaling them so the total remains 1. Also provide an advanced editor for exact probabilities.

### Wildcards

Current default:
- 5 independent wildcard slots per population per generation;
- each activates with probability 0.5;
- a wildcard genome draws every one of the 112 loci independently, uniform over that locus's fixed expanded G0 range;
- wildcards replace ordinary lottery-cross births, never guaranteed-fatherhood children.

Expose slot count and activation probability.

## Stable breeding PRNG

Future browser generations need deterministic stochastic breeding. Use a versioned, cross-browser deterministic PRNG implemented with integer operations, not `Math.random()`.

Recommended canonical v1: **SplitMix64 using BigInt**.
- store the decimal seed string and PRNG version in every generation manifest;
- default next generation seed = parent generation seed + 1;
- R29 historical seed = `202608231655`;
- therefore default R30 seed = `202608231656`.

The game engine should not consume this breeding RNG. Keep breeding randomness isolated so worker scheduling cannot alter offspring.

## Manual population interventions

Interventions are queued against a parent generation and recorded in the child manifest.

Support at least:

### Manual migrant / move
Guarantee an existing parent general as an entrant to a different population's next-generation survivor/entrant pool. It leaves its source population if it otherwise would have survived. It does not breed during the move cycle, matching automatic migrant timing.

### Copy into population
Copy a parent's genome into a destination population as a guaranteed next-generation entrant with a new unique ID; the source remains. The copy does not breed in the insertion cycle.

### Replace/edit advanced operation
Allow an explicit uploaded/manual genome to occupy a selected next-generation entrant slot, with schema and 112-locus validation.

Manual entrants displace the lowest-priority native survivors so that each population still has exactly 14 survivor/entrant slots and ultimately 49 roster members. Reject an intervention set that cannot resolve to 49 per population.

Manual interventions do not silently count against the automatic migration maximum; record automatic and manual entrants separately.
