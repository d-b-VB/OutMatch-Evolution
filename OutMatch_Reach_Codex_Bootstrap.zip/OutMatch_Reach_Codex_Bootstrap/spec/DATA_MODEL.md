# Core data model

## General

Required fields should preserve R29 metadata where present:

```ts
type General = {
  id: string;
  name: string;
  generation: string;
  sourceGeneration?: string;
  origin: string;
  parents: string[];
  father?: string | null;
  mother?: string | null;
  population: PopulationId;
  populationName?: string;
  populationRole?: string;
  selectionTarget?: string;
  genes: Genome112;
  selfCross?: boolean;
};
```

A genome is the same nested category/key structure as R29. Do not collapse it to an unlabeled vector in persistent files. A vectorized internal representation is fine if it has a tested reversible locus-name mapping.

## Population IDs

Fixed v1 enumeration:

```text
horse_lords
pike_lords
archer_lords
horse_hunters
pike_hunters
archer_hunters
generalists
```

## Completed generation

A completed generation is conceptually:

```ts
type Generation = {
  manifest: GenerationManifest;
  population: General[];      // 343, 49 each
  rankings: RankingRow[];     // 343
  ledgerRef: string;          // separate IndexedDB store
  controls: ControlsSnapshot;
  interventions: Intervention[];
  migration: MigrationSummary;
  breeding: BreedingSummary;  // describes construction of this roster from parent
  reports: ReportCache;
};
```

## Ledger

Historical exact field definitions are in `LEDGER_DATA_DICTIONARY.json`.

Future ledger should add at least:
- `gameId` stable string;
- `engineRulesVersion`;
- `redPokeKills`;
- `bluePokeKills`.

Stable game IDs should be derived from generation + stage + ordered schedule index rather than worker completion order.

## Controls snapshot

Every generation must preserve the exact selection/breeding/migration controls that were used to produce/select it. Never infer them later from current UI settings.

`seed/default_controls_r29.json` is the baseline schema/default example.

## Intervention

Suggested:

```ts
type Intervention =
  | { type: "manual-move"; generalId: string; from: PopulationId; to: PopulationId; note?: string }
  | { type: "copy-entrant"; sourceGeneralId: string; to: PopulationId; newId: string; newName?: string; note?: string }
  | { type: "custom-entrant"; to: PopulationId; general: General; note?: string };
```

Store the user-requested operation plus the resolved survivor/birth displacement in the child generation manifest.

## Run / branch

A run is a local lineage of immutable completed generations. Importing a generation can create a new run beginning at that generation. This gives the user experimental branches without needing Git branches or cloud storage.
