# Historical R29 ledger notes

`seed/r29/Reach_R29_Full_Staged_Ledger.csv` is the regression dataset for the transferred ecology.

It has 72,556 rows and no explicit CSV index column. Treat row number 0..72,555 as `gameIndex` for regression fixtures.

Important semantics:
- `redP/redA/redC` and Blue equivalents count units **trained during the game**, excluding each side's three initial P/A/C units.
- `redPokes/bluePokes` count stationary Reach poke actions.
- R29 did not separately record which P kills were stationary poke kills; future ledgers must add that instrumentation.
- `KillBy*` classifies the attacker that made the kill.
- `Victim*` classifies the killed enemy unit.
- `redScore/blueScore` are raw natural-elimination speed scores before population-specific Hunter/Pike-Lord modifiers.
- non-elimination at round 20 is a draw in this ecology.
