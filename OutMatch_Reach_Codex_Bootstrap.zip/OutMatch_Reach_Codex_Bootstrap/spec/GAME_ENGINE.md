# Game engine specification

## Authoritative evaluator

Port from:

`reference/g67v2/current/CURRENT_PLAYABLE_ENGINE_EXACT.js`

Read `reference/g67v2/README_CODEX.md` and `reference/g67v2/docs/ENGINE_FUNCTION_MAP.md` first. Do not use `legacy_reference_DO_NOT_USE`.

The exact function implementation wins over this summary except for the intentional Reach rule patch below.

## Board and initial state

- radius-3 hex board, 37 cells;
- Red moves first;
- initial Red: P(-2,0), A(-3,1), C(-2,-1);
- initial Blue: P(2,0), A(3,-1), C(2,1);
- all units existing at the start of a side turn may activate once that side turn;
- round cap 20.

## Units

- **Pikeman P:** moves one hex and may capture by moving onto an enemy.
- **Archer A:** moves one hex and can shoot an adjacent enemy before or after moving.
- **Cavalry C:** moves up to three hexes, can pass through friendlies, cannot pass through a cell adjacent to an enemy pikeman, but may enter such a cell.

## Reach patch — mandatory

Current Reach rule:

> A Pikeman may kill an adjacent enemy without moving. This is a **poke**. The pikeman stays on its current hex. The poke consumes that pikeman's activation/action. Ordinary one-hex movement and advance-capture remain legal.

The action generator therefore needs a distinct `poke` action for each adjacent enemy available to an unactivated P. Applying it removes the enemy, credits captured material/kills, leaves the P in place, and marks that P activated.

Poke actions must be considered by the same current genome-driven candidate ordering / depth-3 search as all other legal tactical actions. A poke capture should receive capture-related evaluation rather than being treated as a no-op because the attacker does not move.

Add instrumentation:
- side poke attempts/actions;
- side poke kills (future ledgers must distinguish this; historical R29 only stored total pokes);
- action trace entry with attacker id/position, victim id/type/position, side, round.

### Golden-game authority

If there is a subtle ambiguity about how to integrate poke into candidate ordering or capture evaluation, use `fixtures/r29_golden_games.csv`: the correct Reach implementation must reproduce those aggregate games. R29 behavior wins over an intuitively appealing rewrite.

## Reinforcements

- commit a hidden reinforcement on odd rounds;
- it deploys adjacent to that side's base on the side's next turn;
- recruitment and deployment are genome driven by the current exact evaluator.

For AI-vs-AI evolution, both genomes are known to the simulator; preserve game behavior rather than human-UI information hiding semantics.

## Genome evaluator

112 numeric loci. Preserve exact interpretation from the G67 source.

Important functions in the extracted source include:
- `recruitScores` / `aiRecruit`;
- `deploymentSpots` / `aiDeploy`;
- legal move/action generation and application;
- `featureScore`;
- `orderedCandidateActions`;
- `actionIncrement`;
- `lookahead`;
- depth-3 receding horizon, candidate breadth cap 8, carried beam cap 4;
- replanning after every activation.

## Evolutionary game termination / raw score

For the Reach ecology, **natural elimination is the only win condition used in selection**.

If one side eliminates the other at round `r`:

- winner raw score = `1 + 0.5 * (20 - r) / 19`
- loser raw score  = `-0.5 * (20 - r) / 19`

If round 20 ends without natural elimination:

- outcome = `draw`
- raw score = 0 for each side.

Do not use the G67 human-playable material/captured-material/pressure adjudication to convert these ecology draws into wins.

## Determinism

The current AI game itself should be deterministic for fixed genomes/colors/rules. Do not introduce random exploration into tournament gameplay. Breeding is the stochastic component and has its own recorded PRNG seed.
