#!/usr/bin/env python3
"""Zero-dependency regression check for key R29 report fixtures."""
import csv, json, math, pathlib, statistics
from collections import defaultdict

ROOT=pathlib.Path(__file__).resolve().parents[1]
ck=json.load(open(ROOT/'seed/r29/Reach_R29_Complete_Checkpoint.json',encoding='utf-8'))
idpop={g['id']:g['population'] for g in ck['population']}; pops=ck['populationOrder']

# elimination matrix
num=defaultdict(int); den=defaultdict(int)
with open(ROOT/'seed/r29/Reach_R29_Full_Staged_Ledger.csv',newline='',encoding='utf-8') as fh:
    for row in csv.DictReader(fh):
        rp=idpop[row['redId']]; bp=idpop[row['blueId']]
        den[rp,bp]+=1; den[bp,rp]+=1
        if row['outcome']=='elimination':
            if row['winner']=='R': num[rp,bp]+=1
            elif row['winner']=='B': num[bp,rp]+=1
exp=json.load(open(ROOT/'fixtures/r29_elimination_matrix_expected.json',encoding='utf-8'))['matrix']
for a in pops:
    for b in pops:
        if a==b: continue
        got=num[a,b]/den[a,b]
        assert abs(got-exp[a][b])<1e-15,(a,b,got,exp[a][b])

# genetic similarity using frozen stored baseline (not recomputed quantiles)
base=json.load(open(ROOT/'seed/genetic_similarity_baseline_r29.json',encoding='utf-8'))
loci=base['locusOrder']; q=base['loci']
def flat(g):
    d={}
    for cat,block in g['genes'].items():
        for k,v in block.items(): d[f'{cat}.{k}']=float(v)
    return d
F={g['id']:flat(g) for g in ck['population']}
def sim(a,b):
    total=0.0
    for loc in loci:
        span=q[loc]['span']; diff=abs(F[a][loc]-F[b][loc])
        part=(1.0 if diff==0 else 0.0) if span==0 else max(0.0,1-diff/span)
        total+=part
    return total/len(loci)
expected=json.load(open(ROOT/'fixtures/r29_genetic_similarity_expected.json',encoding='utf-8'))['matrix']
for ia,a in enumerate(pops):
    A=[g['id'] for g in ck['population'] if g['population']==a]
    for ib,b in enumerate(pops):
        if ib<ia: continue
        B=[g['id'] for g in ck['population'] if g['population']==b]
        vals=[]
        if a==b:
            for x in range(len(A)):
                for y in range(x+1,len(A)): vals.append(sim(A[x],A[y]))
        else:
            for x in A:
                for y in B: vals.append(sim(x,y))
        got=sum(vals)/len(vals)
        assert abs(got-expected[a][b])<1e-12,(a,b,got,expected[a][b])
print('OK: R29 elimination and genetic-similarity report fixtures reproduce.')
