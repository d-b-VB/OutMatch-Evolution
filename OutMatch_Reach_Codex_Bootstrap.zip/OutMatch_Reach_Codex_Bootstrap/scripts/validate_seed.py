#!/usr/bin/env python3
"""Small zero-dependency sanity check for the transferred ReachR29 checkpoint."""
import json, math, pathlib, sys
from collections import Counter

ROOT=pathlib.Path(__file__).resolve().parents[1]
P=ROOT/'seed'/'r29'/'Reach_R29_Complete_Checkpoint.json'
d=json.load(open(P,encoding='utf-8'))
assert d['generation']=='ReachR29'
assert d['populationSize']==343 and d['populationSizeEach']==49
assert d['nextRecruitingPopulation']=='horse_hunters'
assert len(d['population'])==343
ids=[g['id'] for g in d['population']]
assert len(set(ids))==343
counts=Counter(g['population'] for g in d['population'])
assert all(counts[p]==49 for p in d['populationOrder'])

def flatten(g):
    vals=[]
    for cat,block in g['genes'].items():
        if isinstance(block,dict): vals.extend(block.values())
        else: vals.append(block)
    return vals
for g in d['population']:
    vals=flatten(g)
    assert len(vals)==112, (g['id'],len(vals))
    assert all(isinstance(v,(int,float)) and math.isfinite(v) for v in vals)
print('OK: ReachR29 = 343 unique generals, 49 x 7, 112 finite numeric loci each.')
