#!/usr/bin/env python3
"""Reference/oracle for current ReachR29 selection fitness.

Zero external dependencies. It reconstructs every R29 general's base/final fitness
from the canonical ledger and compares it to the canonical rankings CSV.
A JS/TS port should agree to ordinary double-precision tolerance.
"""
import csv, json, math, pathlib, statistics
from collections import defaultdict

ROOT=pathlib.Path(__file__).resolve().parents[1]
CK=ROOT/'seed'/'r29'/'Reach_R29_Complete_Checkpoint.json'
LED=ROOT/'seed'/'r29'/'Reach_R29_Full_Staged_Ledger.csv'
RANK=ROOT/'seed'/'r29'/'Reach_R29_Full_Staged_Rankings.csv'

ck=json.load(open(CK,encoding='utf-8'))
idpop={g['id']:g['population'] for g in ck['population']}
games=defaultdict(list)

def i(row,key): return int(float(row[key]))
def f(row,key): return float(row[key])

with open(LED,newline='',encoding='utf-8') as fh:
    for row in csv.DictReader(fh):
        for red in (True,False):
            s='red' if red else 'blue'; o='blue' if red else 'red'; color='R' if red else 'B'
            gid=row[s+'Id']; opp=row[o+'Id']
            games[gid].append({
                'oppPop': idpop[opp], 'color':color, 'outcome':row['outcome'], 'winner':row['winner'],
                'score':f(row,s+'Score'),
                'P':i(row,s+'P'),'A':i(row,s+'A'),'C':i(row,s+'C'),
                'oP':i(row,o+'P'),'oA':i(row,o+'A'),'oC':i(row,o+'C'),
                'kP':i(row,s+'KillByP'),'kA':i(row,s+'KillByA'),'kC':i(row,s+'KillByC'),
                'vP':i(row,s+'VictimP'),'vA':i(row,s+'VictimA'),'vC':i(row,s+'VictimC'),
            })

TARGET_POP={'horse_hunters':'horse_lords','pike_hunters':'pike_lords','archer_hunters':'archer_lords'}
TARGET_UNIT={'pike_lords':'C','horse_hunters':'C','pike_hunters':'P','archer_hunters':'A'}

def mean(xs): return sum(xs)/len(xs)

def calc(gid,pop):
    rows=games[gid]
    # game-level selection adjustments
    byopp=defaultdict(list)
    for r in rows:
        adjusted=r['score']
        if pop in TARGET_UNIT:
            u=TARGET_UNIT[pop]
            trained=r['o'+u]
            killed=r['v'+u]
            coverage=math.sqrt(killed/(1+trained))
            won=(r['outcome']=='elimination' and r['winner']==r['color'])
            lost=(r['outcome']=='elimination' and r['winner']!=r['color'])
            if won:
                adjusted=r['score']*(1+math.sqrt(trained))
            elif pop in TARGET_POP and lost:
                adjusted=r['score']*(1-0.5*coverage)
            elif pop in TARGET_POP and r['outcome']=='draw':
                adjusted=0.25*coverage
        byopp[r['oppPop']].append((r,adjusted))

    pop_means={opp:mean([adj for _,adj in entries]) for opp,entries in byopp.items()}
    if pop in TARGET_POP:
        target=TARGET_POP[pop]
        base=(6*pop_means[target] + sum(v for k,v in pop_means.items() if k!=target))/(6+len(pop_means)-1)
    else:
        base=mean(list(pop_means.values()))

    # Opponent-population-normalized training and kill composition.
    recruit_parts=[]; kill_parts=[]; pike_means=[]
    for opp,entries in byopp.items():
        rs=[sum(r[u] for r,_ in entries) for u in 'PAC']; rd=sum(rs)
        ks=[sum(r['k'+u] for r,_ in entries) for u in 'PAC']; kd=sum(ks)
        recruit_parts.append([x/rd if rd else 0.0 for x in rs])
        kill_parts.append([x/kd if kd else 0.0 for x in ks])
        pike_means.append(mean([r['P'] for r,_ in entries]))
    recruit=[mean([x[j] for x in recruit_parts]) for j in range(3)]
    kills=[mean([x[j] for x in kill_parts]) for j in range(3)]
    pikes_per_game=mean(pike_means)

    fitness=base
    if pop=='horse_lords': fitness*=recruit[2]*math.sqrt(kills[2])
    elif pop=='archer_lords': fitness*=recruit[1]*math.sqrt(kills[1])
    elif pop=='pike_lords': fitness*=math.sqrt(pikes_per_game)*math.sqrt(kills[0])
    return base,fitness

max_base=max_fit=0.0; n=0
with open(RANK,newline='',encoding='utf-8') as fh:
    for row in csv.DictReader(fh):
        base,fit=calc(row['id'],row['population'])
        eb=abs(base-float(row['base'])); ef=abs(fit-float(row['fitness']))
        max_base=max(max_base,eb); max_fit=max(max_fit,ef); n+=1
        if eb>=1e-12 or ef>=1e-12:
            raise AssertionError((row['id'],row['population'],base,row['base'],fit,row['fitness'],eb,ef))
print(f'OK: {n} R29 generals. max base error={max_base:.3g}; max fitness error={max_fit:.3g}')
