# Ready-to-paste Codex prompt

You are starting from a brand-new repository containing the OutMatch Reach Ecology bootstrap package. You have no other context and should assume there is no hidden prior conversation.

Read `README.md`, then `CODEX_TASK.md`, then `SOURCE_OF_TRUTH.md`, and follow the specifications under `spec/`.

Build the complete static GitHub Pages OutMatch Reach Evolution Lab described there. Do not substitute an older OutMatch engine or simplify the 112-locus evaluator. Preserve the exact G67 evaluator source under `reference/g67v2/current/`, add the specified Reach stationary pike-poke rule, and use the R29 fixtures as regression gates.

Work through the implementation phases in `CODEX_TASK.md`. Run the supplied Python reference checks before and during the port. Do not consider the project complete until `spec/ACCEPTANCE_TESTS.md` is satisfied.

The app must run evolution client-side, save generations in IndexedDB, support generation `.omgen` download/upload, expose the requested reports and ecological levers, and require no cloud/backend service.

ReachR29 is the immutable transfer boundary. R30 is the first generation that the new browser implementation will create after all R29 validation gates pass.
