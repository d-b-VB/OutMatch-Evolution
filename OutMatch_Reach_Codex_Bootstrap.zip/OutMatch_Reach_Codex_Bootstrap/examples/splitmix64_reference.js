// Canonical suggested breeding PRNG v1. Do not use this RNG inside game AI.
// Seed is stored as a decimal string in generation manifests.
export function makeSplitMix64(seedDecimalString) {
  const MASK = (1n << 64n) - 1n;
  let state = BigInt(seedDecimalString) & MASK;
  function nextUint64() {
    state = (state + 0x9E3779B97F4A7C15n) & MASK;
    let z = state;
    z = ((z ^ (z >> 30n)) * 0xBF58476D1CE4E5B9n) & MASK;
    z = ((z ^ (z >> 27n)) * 0x94D049BB133111EBn) & MASK;
    z = z ^ (z >> 31n);
    return z & MASK;
  }
  function nextFloat() {
    // top 53 bits -> [0,1), exactly representable denominator
    return Number(nextUint64() >> 11n) / 9007199254740992;
  }
  return { nextUint64, nextFloat, getState: () => state.toString() };
}
