# OutMatch G67 Codex Handoff v2

## Critical instruction

**Do not use an older OutMatch genome evaluator to translate these genomes into moves.**

For current genome -> recruitment -> deployment -> move behavior, the source of truth is:

1. `current/OutMatch_Sun_Tzu_G67_Enrollees_Playable_v6.html`
2. `current/CURRENT_PLAYABLE_ENGINE_EXACT.js`

`CURRENT_PLAYABLE_ENGINE_EXACT.js` is an exact extraction of the JavaScript `<script>` block from the v6 playable, not a rewritten approximation.

If the repository already contains another OutMatch evaluator, treat it as legacy until it has been regression-tested against this source.

## What is in this package

### `current/`
- `OutMatch_Sun_Tzu_G67_Enrollees_Playable_v6.html`
  - Exact current human-vs-AI playable environment.
  - Contains the current genome-to-behavior evaluator.
  - Uses the eight unmodified G66 generals selected as Sun Tzu's G67 students.
- `CURRENT_PLAYABLE_ENGINE_EXACT.js`
  - Exact script extracted from the playable HTML.
  - This is the most convenient code reference for porting the current engine.
- `CURRENT_ENGINE_CONFIG.json`
  - Compact statement of the current canonical parameters and source-of-truth hierarchy.

### `genetics/`
- `outmatch_G67_contestants_named.json`
  - Full current G67 population (343 genomes).
- `G66_sources_persisted_or_bred_into_G67.json`
  - Every G66 general that either persisted unchanged into G67 or contributed genes to a new G67 contestant, including the full exact G66 record/genome and G67 contribution links.
- `G66_sources_persisted_or_bred_into_G67_index.csv`
  - Compact index of that immediate source pool.

### `legacy_reference_DO_NOT_USE/`
- `outmatch_continuous_runner_OLD.py`
  - Retained only to help identify obsolete code.
  - It is **not** the current tournament or evaluator.

## Current engine behavior that must be preserved

- Radius-3 hex board.
- Red always moves first.
- Initial position:
  - Red P(-2,0), A(-3,1), C(-2,-1)
  - Blue P(2,0), A(3,-1), C(2,1)
- Every existing unit activates once each side turn.
- Pikeman: move 1; capture by moving onto an enemy.
- Archer: move 1 and may shoot an adjacent enemy either before or after moving.
- Cavalry: move up to 3; can pass through friendlies; cannot pass through a hex adjacent to an enemy pikeman, but may enter such a hex.
- Reinforcement is committed on odd rounds and deploys on the side's next turn adjacent to its base.
- Opponent reinforcement choice is hidden until deployment in the human-play UI.
- AI recruitment is genome-driven via `recruitScores()` / `aiRecruit()`.
- AI deployment is genome-driven via `aiDeploy()`.
- Tactical move choice is genome-driven with depth-3 receding-horizon search.
- Candidate breadth cap = 8.
- Carried beam cap = 4.
- The AI replans after every activation rather than committing an entire turn sequence once.
- Round cap = 20.
- Material values: P=100, A=105, C=110.
- At round cap, adjudicate by material, then captured material, then pressure, otherwise draw.

## Important differences from obsolete engines/runners

The retained old runner is visibly from a different era of the project. It expects:
- population size 256 instead of 343;
- sixteen groups of sixteen instead of the current 7x7x7 tournament;
- 76 loci instead of the current 112-locus genomes;
- an imported `outmatch_recovered_ecology_20round` evaluator that is not the current source of truth;
- a 5,610-game schedule rather than the current 4,446-game canonical tournament+rampage schedule.

Do not infer current behavior from that runner.

## Current tournament format

Canonical 7x7x7:
- 343 entrants -> 49 pod winners -> 7 pod winners -> final 7.
- Each 7-player pod is a double round robin (both colors).
- Layer 1: 49 pods = 2,058 games.
- Layer 2: 7 pods = 294 games.
- Final 7 double round robin = 42 games.
- Top 3 then rampage the population, both colors, excluding self = 2,052 games.
- Total = 4,446 games.

Ranking fitness:
`0.35 * ordinary + 0.25 * continuous + 0.40 * naturalEliminationRate`

Continuous outcome:
- winner at round r: `1 - (r - 1)/40`
- loser: `(r - 1)/40 - 0.05`
- draw: `0.45`

## About the previous fast C++ engine

During the G64-G66 simulations, ChatGPT built a standalone JavaScript recovery and then a C++ performance port plus a Python tournament orchestrator.

Historical validation recorded at the time:
- recovered JavaScript vs historical G59 fixtures: 200/200 winner/outcome/round/material matches;
- C++ port vs those same fixtures: 200/200 winner/outcome/round/material matches;
- pressure was not bit-identical in every historical game (110/200 exact), but the discrepancy did not alter those tested outcomes;
- the C++ port was used because it was dramatically faster for full 4,446-game tournaments.

The exact temporary source files (`outmatch_engine.js`, `outmatch_fast.cpp`, `outmatch_tournament_fast.py`, `export_genomes.py`) were not persisted to the Library and are not recoverable byte-for-byte in this workspace.

**Do not substitute a guessed recreation of those files.** If a fast headless/C++ engine is needed, port from `CURRENT_PLAYABLE_ENGINE_EXACT.js` and establish regression tests first.

## Suggested Codex migration rule

Before replacing the current playable engine with any repository engine:

1. Load representative G67 genomes from `genetics/outmatch_G67_contestants_named.json`.
2. Run identical board states through both evaluators.
3. Compare:
   - recruitment choice,
   - deployment choice,
   - ordered candidate actions,
   - first selected action after depth-3 search,
   - complete deterministic games when both sides use fixed genomes.
4. Do not switch engines until discrepancies are understood.

The current playable source wins any disagreement unless the game specification is deliberately revised.
