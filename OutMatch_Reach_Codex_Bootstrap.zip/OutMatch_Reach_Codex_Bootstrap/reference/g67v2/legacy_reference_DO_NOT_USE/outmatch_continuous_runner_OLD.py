import sys, json, csv, random, itertools, time, os, re, hashlib
from pathlib import Path
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor
sys.path.insert(0,'/mnt/data')
import outmatch_recovered_ecology_20round as om
ROUND_CAP=20; NODE_BUDGET=3
PROV=re.compile(r'^(Wildcard|Mutation|Cross|Elim Desc|Historian G|Dunce G|Assassin G|Sun )')
POOLS={
'ramp':['Horatius','Skanderbeg','Jan Zizka','Bajirao','Sertorius','Lautaro','Shaka'],
'elim':['Subutai','Khalid','Aurelian','Turenne','Marlborough','Baybars','Saladin','Nader Shah','Trajan','Heraclius'],
'hist':['Xenophon','Polybius','Thucydides','Procopius','Livy','Tacitus'],
'assn':['Corbulo','Ventidius II','Paullus II','Marcellus','Labienus','Cato'],
'gen':['Stilicho','Theodoric','Alaric','Attila','Oda Nobunaga','Takeda Shingen','Yi Sun-sin','Gustavus Adolphus','Maurice II','Narses II']}

def _play_task(a):
    r,b,s,c,n=a; return r.id,b.id,om.play(r,b,s,c,n)

def load(path):
    d=json.loads(Path(path).read_text()); pop=[om.Genome(x['id'],x['name'],x.get('origin','unknown'),x.get('parents',[]),x.get('emuHeritage',0),x['genes'],x.get('tags',[])) for x in d['population']]
    return {'generation':d['generation'],'population':pop,'rows':d['ranking'],'winners':d.get('qualifyingWinners',[]),'champions':d.get('champions',[])}

def earn_name(g,row,used):
    if not PROV.match(g.name): return g.name
    if row.get('rampageVsFinalists',0)>=4: pool=POOLS['ramp']
    elif g.origin in ('historian','dunce-historian'): pool=POOLS['hist']
    elif g.origin=='assassin': pool=POOLS['assn']
    elif row.get('elimRate',0)>=.35 or row.get('eliminations',0)>=20: pool=POOLS['elim']
    else: pool=POOLS['gen']
    h=int(hashlib.sha256(g.id.encode()).hexdigest()[:8],16)
    for k in range(len(pool)*3):
        base=pool[(h+k)%len(pool)]; name=base+(' Rex' if g.emu>=.35 else '')
        if name not in used: used.add(name); return name
    base=pool[h%len(pool)]; name=f'{base} {g.id[-4:]}' + (' Rex' if g.emu>=.35 else ''); used.add(name); return name

def promote(rep):
    by={g.id:g for g in rep['population']}; rm={r['id']:r for r in rep['rows']}; used={g.name for g in rep['population'] if not PROV.match(g.name)}
    ids=set(r['id'] for r in rep['rows'][:16])|set(rep.get('winners',[]))|set(rep.get('champions',[]))
    ids|={r['id'] for r in rep['rows'] if r.get('rampageVsFinalists',0)>=4}
    ids|=set(r['id'] for r in sorted(rep['rows'],key=lambda x:x.get('elimRate',0),reverse=True)[:24])
    ren=[]
    for gid in ids:
        if gid in by and PROV.match(by[gid].name):
            old=by[gid].name; by[gid].name=earn_name(by[gid],rm[gid],used); rm[gid]['name']=by[gid].name; ren.append((old,by[gid].name))
    return ren

def tournament(pop,gen,seed,workers=None):
    workers=workers or min(20,os.cpu_count() or 4); rr=random.Random(seed+gen); q=pop[:]; rr.shuffle(q); groups=[q[i*16:(i+1)*16] for i in range(16)]
    st={g.id:Counter() for g in pop}; by={g.id:g for g in pop}; games=[]
    def rec(a,b,res):
        out=res['outcome']; w=res['winner']; r=res['rounds']; st[a]['games']+=1; st[b]['games']+=1
        if w:
            wid=a if w=='R' else b; lid=b if w=='R' else a; st[wid]['wins']+=1; st[lid]['losses']+=1
            st[wid]['cont']+=1-(r-1)/40; st[lid]['cont']+=(r-1)/40-.05
            if out=='elimination': st[wid]['elim']+=1
            else: st[wid]['adj']+=1
        else:
            st[a]['draws']+=1; st[b]['draws']+=1; st[a]['cont']+=.45; st[b]['cont']+=.45
        games.append((a,b,out,w,r))
    print(f'Generation {gen}: qualifiers',flush=True); winners=[]
    with ProcessPoolExecutor(max_workers=workers) as ex:
        for gi,grp in enumerate(groups,1):
            tasks=[]; local=Counter(); base=(gi-1)*240; j=0
            for a,b in itertools.combinations(grp,2):
                for rev in (0,1):
                    red,blue=(b,a) if rev else (a,b); tasks.append((red,blue,seed+(base+j)*7+gi,20,3)); j+=1
            for a,b,res in ex.map(_play_task,tasks,chunksize=10):
                rec(a,b,res)
                if res['winner']:
                    wid=a if res['winner']=='R' else b; local[wid]+=50 if res['outcome']=='elimination' else 1
            gw=max(grp,key=lambda x:(local[x.id],st[x.id]['elim'],st[x.id]['wins'])); winners.append(gw); print(f'  {gi:02} {gw.name}',flush=True)
        print(f'Generation {gen}: finals',flush=True); fs=Counter(); tasks=[]; start=len(games); j=0
        for a,b in itertools.combinations(winners,2):
            for rev in (0,1):
                red,blue=(b,a) if rev else (a,b); tasks.append((red,blue,seed+100000+(start+j)*11,20,3)); j+=1
        for a,b,res in ex.map(_play_task,tasks,chunksize=10):
            rec(a,b,res)
            if res['winner']:
                wid=a if res['winner']=='R' else b; fs[wid]+=50 if res['outcome']=='elimination' else 1
        champs=sorted(winners,key=lambda x:(fs[x.id],st[x.id]['elim'],st[x.id]['wins']),reverse=True)[:3]; print('  finalists:',', '.join(x.name for x in champs),flush=True)
        ramp={c.id:Counter() for c in champs}; rival=defaultdict(Counter); tasks=[]; meta=[]; start=len(games); j=0
        for c in champs:
            for o in pop:
                if o.id==c.id: continue
                for rev in (0,1):
                    red,blue=(o,c) if rev else (c,o); tasks.append((red,blue,seed+200000+(start+j)*13,20,3)); meta.append((c.id,o.id)); j+=1
        for (a,b,res),(cid,oid) in zip(ex.map(_play_task,tasks,chunksize=20),meta):
            rec(a,b,res)
            if res['winner']:
                wid=a if res['winner']=='R' else b
                if wid==cid:ramp[cid]['wins']+=1
                else:rival[oid]['wins']+=1
            else:ramp[cid]['draws']+=1;rival[oid]['draws']+=1
        for c in champs: print(f'  rampage {c.name}: {ramp[c.id]["wins"]}/510',flush=True)
    rows=[]
    for gid,s in st.items():
        n=s['games']; e=s['elim']/n; o=(s['wins']+.45*s['draws'])/n; c=s['cont']/n; fit=.35*o+.25*c+.40*e
        rows.append({'id':gid,'name':by[gid].name,'origin':by[gid].origin,'emuHeritage':round(by[gid].emu,3),'games':n,'wins':s['wins'],'losses':s['losses'],'draws':s['draws'],'eliminations':s['elim'],'elimRate':e,'ordinaryScore':o,'continuousScore':c,'fitness':fit,'rampageVsFinalists':rival[gid]['wins']})
    rows.sort(key=lambda r:(r['fitness'],r['eliminations'],r['wins']),reverse=True)
    return {'generation':gen,'rows':rows,'winners':[x.id for x in winners],'champions':[x.id for x in champs],'games':games,'population':pop,'ramp':{k:dict(v) for k,v in ramp.items()}}

def save(rep,path):
    out={'schema':'recovered-neutral-v2-2','generation':rep['generation'],'populationSize':256,'locusCount':76,'roundCap':20,'nodeBudget':3,'fitnessFormula':'0.35*ordinary + 0.25*continuous + 0.40*naturalEliminationRate','continuousFormula':{'win':'1-(r-1)/40','tie':'.45','loss':'(r-1)/40-.05'},'schedule':{'qualifying':3840,'final':240,'rampage':1530,'total':5610},'champions':rep['champions'],'qualifyingWinners':rep['winners'],'ranking':rep['rows'],'population':[{'id':g.id,'name':g.name,'origin':g.origin,'parents':g.parents,'emuHeritage':g.emu,'tags':g.tags,'genes':g.g} for g in rep['population']]}
    Path(path).write_text(json.dumps(out,indent=2))
    with open(path.replace('.json','_ranking.csv'),'w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rep['rows'][0].keys()); w.writeheader(); w.writerows(rep['rows'])

def one(prev_path,gen,seed):
    prev=load(prev_path); before=promote(prev); print('Prior names earned:',before,flush=True)
    pop=om.breed(prev,gen); t=time.time(); rep=tournament(pop,gen,seed); print('seconds',time.time()-t,flush=True); after=promote(rep); print('Names earned:',after,flush=True); save(rep,f'/mnt/data/outmatch_recovered_gen{gen}R.json')
    elim=sum(r['eliminations'] for r in rep['rows']); ties=sum(1 for g in rep['games'] if g[3] is None); quick=sum(1 for g in rep['games'] if g[2]=='elimination' and g[4]<=4)
    print('SUMMARY',gen,'elim',elim,elim/5610,'ties',ties,'quick_elims',quick,flush=True)
    for r in rep['rows'][:12]: print('TOP',r,flush=True)
