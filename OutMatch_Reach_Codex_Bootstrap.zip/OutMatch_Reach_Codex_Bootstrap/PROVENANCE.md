# Package provenance

This bootstrap was assembled from the current OutMatch artifacts available at the ReachR29 transfer boundary.

- The exact G67 Codex handoff was recovered from the existing `d-b-VB/OutMatch` repository and is included both extracted and as its original ZIP.
- The complete ReachR29 checkpoint, full staged ledger, rankings and summary were recovered from the saved OutMatch working artifacts.
- `OutMatch_Seven_Ecology_Founders_G0_v2.json` is included only to preserve the original 112-locus expanded mutation ranges.
- R29 report/fitness fixtures in this package were derived directly from the canonical R29 checkpoint and ledger.
- `scripts/verify_r29_fitness.py` independently reconstructs all 343 canonical R29 fitness values from the ledger to ordinary floating-point precision.

There is no canonical R30 hidden elsewhere in this package. R29 is the transfer point; the new browser implementation establishes the future branch after passing the R29 regression suite.
