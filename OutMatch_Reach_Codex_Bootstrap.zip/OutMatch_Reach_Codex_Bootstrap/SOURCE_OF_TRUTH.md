# Source-of-truth hierarchy

This package intentionally contains historical source material. Some older files describe rules that were later changed. Use this precedence order.

## 1. Current ReachR29 state and rules — highest authority

- `seed/r29/Reach_R29_Complete_Checkpoint.json`
- `seed/r29/Reach_R29_Full_Staged_Ledger.csv`
- `seed/r29/Reach_R29_Full_Staged_Rankings.csv`
- `seed/r29/Reach_R29_Full_Staged_Summary.json`
- the exact formulas in `spec/ECOLOGY.md`, which have been independently verified against every R29 ranking row;
- fixture outputs under `fixtures/`.

If a historical file conflicts with these, R29 wins.

## 2. Exact gameplay/genome evaluator source

`reference/g67v2/current/CURRENT_PLAYABLE_ENGINE_EXACT.js`

This is the exact JavaScript extraction of the authoritative G67 playable engine. Preserve its 112-locus genome interpretation, recruitment, deployment and depth-3 move planning.

**Deliberate Reach difference:** G67's pikeman is pre-Reach. Add the stationary adjacent poke specified in `spec/GAME_ENGINE.md`.

## 3. G0 founder allele ranges — mutation provenance only

`reference/history/OutMatch_Seven_Ecology_Founders_G0_v2.json`

Use this to define the fixed expanded mutation/wildcard range of each of the 112 loci. A convenient exact extraction is already provided as `seed/mutation_ranges.json`.

Do **not** copy its old wildcard-count or migration-count defaults into the current ecology.

## 4. Other historical files

They are useful for provenance/debugging only.

### Explicit supersessions

| Topic | Historical value sometimes visible | Current value |
|---|---|---|
| Pike combat | move-capture only | move-capture **or stationary adjacent poke** |
| Wildcard slots | older ecology used 7 | **5 independent slots** |
| Wildcard activation | 50% | **50% per slot** |
| Migration max | older ecology used 7 | **4** |
| Next recruiting population after R29 | n/a | **Horse Hunters** |
| Hunter target-pop weight | 6× | **6×** |
| Lord selection | older versions had training only | current also includes specialized-unit kill share |
| Hunter non-win target killing | older versions no credit | current loss mitigation/draw reward |
| Ecology outcome at round cap | G67 human playable adjudicates | Reach evolutionary ledger treats non-elimination at round 20 as **draw** |
| Tournament | G67 7×7×7 pods/rampage | Reach three-stage seven-population ecology schedule |

## No hidden context assumption

There is no later canonical generation hidden outside this package that Codex is expected to reproduce. ReachR29 is the transfer boundary. Once the implementation passes the R29 regression fixtures, R30 produced by the new deterministic browser breeder is the new canonical continuation.
